from kasieats import myModule

print(1)